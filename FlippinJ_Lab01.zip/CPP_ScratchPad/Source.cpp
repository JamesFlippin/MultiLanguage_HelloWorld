#include <iostream>

using namespace std;

int main()
{
	cout << "Hello World!" << endl << endl;
	cout << "My Name is James!!!" << endl;
	return 0;
}